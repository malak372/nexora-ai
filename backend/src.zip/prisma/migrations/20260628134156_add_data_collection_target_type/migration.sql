-- AlterEnum
ALTER TYPE "AdminTargetType" ADD VALUE 'DATA_COLLECTION';
