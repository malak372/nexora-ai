import { Injectable } from '@nestjs/common';
import { AiRoutingStrategy, ApiRequestType, PromptType } from '@prisma/client';

import { AiExecutionService } from '../../../ai/services/ai-execution.service';
import { AiResponseParserService } from '../../../ai/services/ai-response-parser.service';
import { AiResponseFormat } from '../../../ai/types/ai-provider.type';

import {
  AI_ENHANCEMENT_OUTPUT_SCHEMA,
  AI_ENHANCEMENT_RESPONSE_SCHEMA_NAME,
} from '../schemas/ai-enhancement-output.schema';

import type {
  NlpAiClientRequest,
  NlpAiClientResponse,
} from '../types/nlp-ai-client.type';

import type { NlpAiClient } from './nlp-ai-client.interface';

/**
 * Deterministic temperature used for analytical NLP enhancement.
 *
 * A low value is preferred because this operation refines an existing
 * evidence-based analysis rather than generating creative content.
 */
const NLP_AI_ENHANCEMENT_TEMPERATURE = 0.2;

/**
 * Production NLP AI-client adapter backed by the central AI runtime.
 *
 * This adapter forms the integration boundary between:
 *
 * NlpModule
 * → AiExecutionService
 * → configured AI providers
 *
 * Responsibilities:
 * - Translate the NLP-specific request contract into AiExecutionInput.
 * - Supply the NLP enhancement JSON Schema to the central AI runtime.
 * - Classify the operation correctly for logging and analytics.
 * - Parse the centrally validated JSON text into an unknown value.
 * - Normalize authoritative execution metadata for the NLP layer.
 *
 * The adapter intentionally does not:
 * - Select an AI model or provider.
 * - Implement retry, timeout, fallback, or health logic.
 * - Validate evidence identifiers.
 * - Merge AI output with rule-based analysis.
 * - Persist NLP results.
 *
 * Provider routing, retries, fallback, response repair, health
 * tracking, cost calculation, operation-ID generation, and
 * ExternalApiLog persistence remain owned by AiExecutionService.
 *
 * Domain-level validation remains owned by
 * AiAnalysisOutputValidatorService because JSON Schema validation
 * cannot verify whether returned evidence identifiers were actually
 * supplied by the NLP pipeline.
 *
 * @author Eman
 */
@Injectable()
export class AiExecutionNlpClient implements NlpAiClient {
  constructor(
    private readonly aiExecutionService: AiExecutionService,
    private readonly aiResponseParserService: AiResponseParserService,
  ) {}

  /**
   * Executes one structured NLP AI-enhancement operation.
   *
   * AiExecutionService validates the provider response against
   * AI_ENHANCEMENT_OUTPUT_SCHEMA before returning successful text.
   *
   * The parsed value remains unknown so the NLP-specific validator can
   * enforce evidence references and domain business rules before the
   * value enters the final analysis.
   *
   * @param request Fully rendered NLP AI-enhancement request.
   * @returns Parsed response and authoritative execution metadata.
   */
  async enhance(request: NlpAiClientRequest): Promise<NlpAiClientResponse> {
    const result = await this.aiExecutionService.execute({
      userPrompt: request.prompt,
      systemInstruction: [
        'Analyze only the supplied evidence records.',
        'Return one JSON object and no Markdown or explanatory text.',
        'Do not invent evidence identifiers, statistics, locations, or facts.',
        'Use null only where the response schema explicitly allows it.',
      ].join(' '),
      requestType: ApiRequestType.NLP_ENHANCEMENT,
      promptType: PromptType.NLP_ANALYSIS,
      responseFormat: AiResponseFormat.JSON,
      responseSchema: AI_ENHANCEMENT_OUTPUT_SCHEMA,
      responseSchemaName: AI_ENHANCEMENT_RESPONSE_SCHEMA_NAME,
      temperature: NLP_AI_ENHANCEMENT_TEMPERATURE,
      strategy: AiRoutingStrategy.BALANCED,

      /**
       * NLP prompts are application-controlled. One provider may reject its
       * native schema representation while another provider can execute the
       * same evidence-grounded request safely.
       */
      allowProviderFallbackOnInvalidPrompt: true,
    });

    const data: unknown = this.aiResponseParserService.parseJson(result.text);

    return {
      data,
      operationId: result.operationId,
      aiModelId: result.aiModelId,
      providerKey: result.providerKey,
      apiModelId: result.apiModelId,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      responseTimeMs: result.responseTimeMs,
      costEstimate: result.costEstimate,
      fallbackUsed: result.fallbackUsed,
      attemptCount: result.attemptCount,
    };
  }
}
